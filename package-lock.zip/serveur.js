const express = require("express");
const { createServer } = require("node:http");
const { join } = require("node:path");
const { Server } = require("socket.io");

const app = express();
const server = createServer(app);
const io = new Server(server);

app.get("/", (req, res) => {
  res.sendFile(join(__dirname, "public/main.html"));
});

app.use(express.static("public"));

io.on("connection", (socket) => {
  console.log("a user connected");

  // Join room
  socket.on("join room", (roomId) => {
    socket.join(roomId);
  });

  // Send chat message to all clients in the same room
  socket.on("chat message", (message) => {
    io.emit("chat message", message);
  });

  socket.on("disconnect", () => {
    console.log("user disconnected");
  });
});

server.listen(3000, () => {
  console.log("server running at http://localhost:3000");
});
