document.addEventListener("DOMContentLoaded", function () {
    var socket = io();
    var messageInput = document.getElementById("message-input");
    var sendButton = document.getElementById("send-button");

    // Event listener for sending messages when the send button is clicked
    sendButton.addEventListener("click", function (event) {
        event.preventDefault();
        sendMessage();
    });

    // Event listener for sending messages when the Enter key is pressed
    messageInput.addEventListener("keypress", function (event) {
        if (event.key === "Enter") {
            event.preventDefault();
            sendMessage();
        }
    });

    function sendMessage() {
        var message = messageInput.value.trim();

        if (message !== "") {
            socket.emit('chat message', message); // Sending message to the server
            messageInput.value = ""; // Clearing the input field
        }
    }

    // Event listener for receiving messages from the server
    socket.on('chat message', function (msg) {
        var chatBox = document.getElementById("chat-box");
        var newMessage = document.createElement("div");
        newMessage.textContent = msg;
        chatBox.appendChild(newMessage);
        chatBox.scrollTop = chatBox.scrollHeight; // Auto-scroll to bottom
    });
});
